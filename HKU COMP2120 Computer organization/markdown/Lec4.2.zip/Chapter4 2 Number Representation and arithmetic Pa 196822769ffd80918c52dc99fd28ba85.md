# Chapter4.2  Number Representation and arithmetic Part II

Created: 2025年2月10日 08:53
Class: COMP2120

Floating-point representation

We represent  fractional number as an integer multiplied by a fixed scaling factor.(like “scientific notation”)

In decimal, we have:

$$
Value = \pm Significand\times 10^{Exponent}
$$

Similar to decimal floating point number, in binary we have:

$$
Value = \pm(1.xxxxxxx)_2 \times 2^{Exponent}\\or\\Value = \pm(0.xxxxxxx)_2 \times 2^{Exponent}
$$

To represent it, we use:

![image.png](image.png)

sign bit:  +-, 1 represent negative

Significand: normalized to “1.xxxxxx” or “0.1xxxxx”, begin digit is always 1,  which can be omitted

Exponent: signed number, usually use biased representation or excess $2^{m-1}-1$

e.g.(32-Bit Floating-Point Format)(excess 127 representation, so 10010011=20)

![image.png](image%201.png)

Expressible Numbers:

In Two’s complement, the range is:

![image.png](image%202.png)

In Floating-point numbers, the range is:

$$
2^{-127}<|range|<(1+2^{-1}+...+2^{-23})\times2^{128}\\=(2-2^{-23})\times2^{128}\approx2^{129}
$$

![image.png](image%203.png)

Both of them represent 2^32 numbers.

[IEEE Floating Point Format](https://www.notion.so/IEEE-Floating-Point-Format-196822769ffd8032ade0eee7dc55ed4d?pvs=21)